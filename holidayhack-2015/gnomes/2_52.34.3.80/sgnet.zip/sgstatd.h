int child_main(int sd);
int sgnet_exit();
int sgstatd(int sd);
int main(int argc, char **argv);
